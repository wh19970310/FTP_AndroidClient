package com.example.myclient;

import android.widget.EditText;

public class Var {
    public static String IP;
    public static EditText edit_IP;
}
