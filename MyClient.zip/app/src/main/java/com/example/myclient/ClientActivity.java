package com.example.myclient;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.io.File;
import java.util.Map;

public class ClientActivity extends AppCompatActivity {
    static String Floder;
    public static Handler handler;
    ListView List_File;
    getFileName getFileName;
    Button Btn_Upload;
    Button Btn_Refreah;
    Button Btn_FileManage;
    Button Btn_Quit;
    TextView textView_State;
    String FileName[];
    String path;
    AlertDialog.Builder adb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client);
        final ListView list = findViewById(R.id.list_File);
        adb = new AlertDialog.Builder(ClientActivity.this);
        List_File = findViewById(R.id.list_File);
        getFileName = new getFileName();
        Btn_Upload = findViewById(R.id.Btn_Upload);
        Btn_Refreah = findViewById(R.id.Btn_Refresh);
        Btn_FileManage = findViewById(R.id.Btn_FileManage);
        Btn_Quit = findViewById(R.id.Btn_Quit);
        textView_State = findViewById(R.id.TextView_State);

        Thread thread = new Thread(new getFileName());
        thread.start();

        Btn_FileManage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");//无类型限制
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(intent,1);

            }
        });

        Btn_Upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SendFile sendFile = new SendFile(path,FileName[FileName.length-1],textView_State);
                Thread thread = new Thread(sendFile);
                thread.start();
                File file = new File(path);
                file.length();


            }
        });

        Btn_Refreah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Thread thread = new Thread(new getFileName());
                thread.start();
            }
        });

        Btn_Quit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    Thread thread_Quit = new Thread(new BackFile());
                    thread_Quit.start();
            }
        });



        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final Map<String,Object> item = (Map<String, Object>) parent.getItemAtPosition(position);

                if(item.get("File_Des") != null)
                {
                    adb.setPositiveButton("下载", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            GetFile getFile = new GetFile(item.get("File_Name").toString(),textView_State,item.get("File_Des").toString());
                            Thread thread_GetFIle = new Thread(getFile);
                            thread_GetFIle.start();
                        }
                    });

                    adb.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });

                    adb.setNeutralButton("删除", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            DelFile delFile = new DelFile(item.get("File_Name").toString());
                            Thread thread = new Thread(delFile);
                            thread.start();
                        }
                    });
                    adb.setTitle("选择操作");
                    adb.setMessage(item.get("File_Name").toString());
                    adb.show();
                }
                if(item.get("File_Des") == null)
                {
                    adb.setPositiveButton("打开", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Floder = item.get("File_Name").toString();
                            OpenFile openFile = new OpenFile(item.get("File_Name").toString());
                            Thread thread = new Thread(openFile);
                            thread.start();
                        }
                    });

                    adb.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });

                    adb.setNeutralButton("新建", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    adb.setTitle("选择操作");
                    adb.setMessage(item.get("File_Name").toString());
                    adb.show();
                }

            }
        });

        handler = new Handler()
        {
            @Override
            public void handleMessage(Message msg)
            {
                if(msg.what > 0)
                {
                    textView_State.setText("请稍候，已发送：" + msg.what + "%");
                }
                if(msg.what == -1)
                {
                    finish();
                }
                if(msg.what == -2)
                {
                    SimpleAdapter Sim_ADP;

                    Sim_ADP = new SimpleAdapter(ClientActivity.this, getFileName.listItems,R.layout.activity_item,

                            new String[] {"File_Img", "File_Name", "File_Des"},

                            new int[] {R.id.File_Img,R.id.File_Name,R.id.File_Des});
                    list.setAdapter(Sim_ADP);
                }
                if(msg.what == -3)
                {
                    Conn conn = new Conn();
                    conn.setIP(Var.IP);
                    Thread thread = new Thread(conn);
                    thread.start();
                }
            }

        };

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {//是否选择，没选择就不会继续

            Uri uri = data.getData();//得到uri，后面就是将uri转化成file的过程。
            String[] proj = {MediaStore.Images.Media.DATA};
            Cursor actualimagecursor = managedQuery(uri, proj, null, null, null);
            int actual_image_column_index = actualimagecursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            actualimagecursor.moveToFirst();
            String img_path = actualimagecursor.getString(actual_image_column_index);
            File file = new File(img_path);
            path = file.toString();
            FileName = path.split("/");
            textView_State.setText(FileName[FileName.length-1]);
        }
        else {
            Intent intent = new Intent();
            intent.setClass(ClientActivity.this, ClientActivity.class);
            startActivity(intent);
            finish();
        }
    }
}
