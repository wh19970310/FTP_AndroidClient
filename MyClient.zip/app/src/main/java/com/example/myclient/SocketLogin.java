package com.example.myclient;

import android.os.Message;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

public class SocketLogin extends Thread{
    static Socket socket;
    OutputStream os;
    BufferedReader br;
    String user;
    String pwd;
    String conn;

    public SocketLogin(String user, String pwd)
    {
        this.user = user;
        this.pwd = pwd;
    }

    @Override
    public  void run(){
        try {
            os = socket.getOutputStream();
            os.write(("user:"+user+"###pwd:"+pwd).getBytes());
            br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            while((conn = br.readLine())!=null){
                if(conn.equals("Err"))
                {
                    Message msg = new Message();
                    msg.what = 2;
                    LoginActivity.handler.sendMessage(msg);
                    break;
                }
                if(conn.equals("Accept"));
                {
                    Message msg = new Message();
                    msg.what = 1;
                    LoginActivity.handler.sendMessage(msg);
                    break;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
