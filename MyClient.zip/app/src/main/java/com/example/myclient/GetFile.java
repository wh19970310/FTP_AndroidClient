package com.example.myclient;

import android.os.Message;
import android.util.Log;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;

public class GetFile extends Thread{
    static Socket socket;
    OutputStream os;
    String FileName;
    BufferedInputStream bis;
    float Percent = 0;
    float Size;
    String File_Des[];
    TextView Stat;

    public GetFile(String FileName, TextView Stat,String File_Des)
    {
        this.FileName = FileName;
        this.Stat = Stat;
        this.File_Des = File_Des.split(" ");
    }

    @Override
    public  void run(){
        switch(File_Des[1])
        {
            case "B":Size = Float.parseFloat(File_Des[0])/4096; break;
            case "KB":Size = Float.parseFloat(File_Des[0])/4;break;
            case "M":Size = Float.parseFloat(File_Des[0])*1024*1024/4096;break;
            case "GB":Size = Float.parseFloat(File_Des[0])*1024*1024*1024/4096;break;
        }

        try {
            os = socket.getOutputStream();
            os.write("GetFile".getBytes());
            File dir = new File("/storage/emulated/0/AmyClient/");
            File file = new File("/storage/emulated/0/AmyClient/" + FileName);
            sleep(240);
            os.write(FileName.getBytes());
            InputStream dataStream = socket.getInputStream();

            if (!dir.exists()) {
                dir.mkdirs();
            }
            FileOutputStream fos = new FileOutputStream(file, false);
            byte[] buffer = new byte[4096];
            int size = -1;
            while ((size = dataStream.read(buffer)) != -1) {
                fos.write(buffer, 0, size);
                Percent++;
                if(Percent%64 == 0) {
                    Stat.setText("请稍候，已下载：" + (int)((Percent / (Size*1.85)) * 100) + "%");
                }
            }
            fos.close();
            Stat.setText("下载完成");
            sleep(700);
            Message message = new Message();
            message.what = -3;
            ClientActivity.handler.sendMessage(message);
            Stat.setText("");

        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
