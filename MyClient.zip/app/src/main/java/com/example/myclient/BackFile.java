package com.example.myclient;

import android.os.Message;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BackFile extends Thread{
    static Socket socket;
    OutputStream os;
    BufferedReader br;
    public static List<Map<String,Object>> listItems = new ArrayList<Map<String,Object>>();

    public int Img_ID[];

    {
        Img_ID = new int[]
                {R.drawable.floder,R.drawable.file};
    }

    String FileNames[] = new String[1024];
    String str;
    int n = 0;

    @Override
    public  void run() {
        try {
            os = socket.getOutputStream();
            os.write("BackFile".getBytes());
            sleep(240);

            br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            str = br.readLine();
            while (str != null)
            {
                FileNames[n] = str;
                n++;
                str = br.readLine();
                if(str.equals("")) {
                    break;
                }
            }

            for(int i = 0;i < n;i++)
            {
                Map<String,Object> listItem = new HashMap<String, Object>();
                String Type[] = FileNames[i].split("#");
                if(Type[0].equals("文件夹"))
                {

                    listItem.put("File_Img",Img_ID[0]);
                    listItem.put("File_Name",Type[1]);
                }
                else
                {
                    listItem.put("File_Img",Img_ID[1]);
                    listItem.put("File_Name",Type[1]);
                    String Size[] = Type[0].split("文");
                    int size = Integer.parseInt(Size[0]);
                    int  type = 0;
                    while(size > 1024)
                    {
                        size = size/1024;
                        type++;
                        if(type == 3)
                        {
                            break;
                        }
                    }
                    switch(type)
                    {
                        case 0:Type[0] = size + "B"; break;
                        case 1:Type[0] = size + "KB";break;
                        case 2:Type[0] = size + "M";break;
                        case 3:Type[0] = size + "GB";break;
                    }
                    listItem.put("File_Des",Type[0]);
                }
                listItems.add(listItem);
            }
            Message msg = new Message();
            msg.what = -2;
            ClientActivity.handler.sendMessage(msg);

        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
