package com.example.myclient;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static android.support.v7.app.AlertDialog.*;


public class MainActivity extends Activity {
    public static Handler handler;
    static EditText Edit_IP;
    Button Btn_Conn;
    static String IP;
    public String login = "NO";// = "OK";
    Conn conn;

    String regex = "^(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|[1-9])\\."
            + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."
            + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."
            + "(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)$";
    AlertDialog.Builder adb;

    @SuppressLint("HandlerLeak")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Btn_Conn = findViewById(R.id.Btn_Conn);
        Edit_IP = findViewById(R.id.Edit_IP);

        Btn_Conn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                IP = Edit_IP.getEditableText().toString();
                if (!(IP.matches(regex))) {
                    adb = new Builder(MainActivity.this);
                    adb.setPositiveButton("OK！", new OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
                    adb.setTitle("WARNING！");
                    adb.setMessage("非法IP！");
                    adb.show();
                }
                else {
                    Toast.makeText(MainActivity.this,"连接中…",Toast.LENGTH_SHORT).show();
                    conn = new Conn();
                    conn.setConn(IP,Edit_IP);
                    Thread thread = new Thread(conn);
                    thread.start();
                }
            }
        });

        handler = new Handler()
        {
            @Override
            public void handleMessage(Message msg)
            {
                if(msg.what == 1)
                {
                    Intent intent = new Intent();
                    intent.setClass(MainActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish();
                }
                else
                {
                    Toast.makeText(MainActivity.this,"连接失败",Toast.LENGTH_SHORT).show();
                }
            }

        };
    }
}