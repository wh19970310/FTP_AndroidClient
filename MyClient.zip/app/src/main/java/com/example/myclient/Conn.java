package com.example.myclient;

import android.os.Message;
import android.widget.EditText;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

public class Conn extends Thread {

    int Port = 8520;
    private String IP;
    static Socket socket;
    public EditText Edit_IP;
    Message msg = new Message();
    static int con = 0;

    public void setConn(String IP, EditText edit_IP) {
        this.IP = IP;
        this.Edit_IP = edit_IP;
    }
    public void setIP(String IP)
    {
        this.IP = IP;
    }

    public static int Quit() throws IOException {

        socket.close();
        if(!(socket.isConnected() && !socket.isClosed()))
        {
            return 1;
        }
        else
        {
            return 0;
        }

    }

    @Override
    public void run() {
        socket = new Socket();
        SocketAddress socketAddress = new InetSocketAddress(IP, Port);
        try {
            socket.connect(socketAddress, 5000);
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(socket.isConnected() && !socket.isClosed()) {
            Var.IP = IP;
            SocketLogin.socket = socket;
            getFileName.socket = socket;
            SendFile.socket = socket;
            BackFile.socket = socket;
            GetFile.socket = socket;
            DelFile.socket = socket;
            OpenFile.socket = socket;
            if(con == 0) {
                msg.what = 1;
                MainActivity.handler.sendMessage(msg);
                con = 1;
            }
        }
        else
        {
            Edit_IP.setText("请输入可用地址");
            msg.what = 0;
            MainActivity.handler.sendMessage(msg);
        }

    }
}