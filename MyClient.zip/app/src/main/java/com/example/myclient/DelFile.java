package com.example.myclient;

import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

public class DelFile extends Thread{
    String FileName;
    static Socket socket;
    OutputStream os;

    public DelFile(String FileName)
    {
        this.FileName = FileName;
    }

    @Override
    public  void run() {
        try {
            os = socket.getOutputStream();
            os.write("DelFile".getBytes());
            sleep(240);
            os.write(FileName.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }
}
