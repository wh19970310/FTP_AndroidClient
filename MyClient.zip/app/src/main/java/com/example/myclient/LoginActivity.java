package com.example.myclient;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity{
    public static Handler handler;
    Button Btn_Quit;
    Button Btn_Login;
    EditText editText_User;
    EditText editText_PWD;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final ImageView IV_Del_UserName = findViewById(R.id.imageView);
        final ImageView IV_Del_PWD = findViewById(R.id.imageView2);
        Btn_Quit = findViewById(R.id.button2);
        Btn_Login = findViewById(R.id.button);
        editText_User = findViewById(R.id.editText);
        editText_PWD = findViewById(R.id.editText2);

        IV_Del_UserName.setVisibility(View.GONE);
        IV_Del_PWD.setVisibility(View.GONE);

        IV_Del_UserName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText_User.setText("");
            }
        });
        IV_Del_PWD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText_PWD.setText("");
            }
        });

        Btn_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = editText_User.getEditableText().toString();
                String pwd = editText_PWD.getEditableText().toString();
                SocketLogin socketLogin = new SocketLogin(user,pwd);
                Thread thread = new Thread(socketLogin);
                thread.start();
            }
        });
        Btn_Quit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Thread thread = new Thread(new BackFile());
                thread.start();
            }
        });

        TextWatcher textWatcher = new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

                if (editText_User.getEditableText().length() >= 1) {
                    IV_Del_UserName.setVisibility(View.VISIBLE);
                } else {
                    IV_Del_UserName.setVisibility(View.GONE);
                }

                if (editText_PWD.getEditableText().length() >= 1) {
                    IV_Del_PWD.setVisibility(View.VISIBLE);
                } else {
                    IV_Del_PWD.setVisibility(View.GONE);
                }

            }
        };

        editText_User.addTextChangedListener(textWatcher);
        editText_PWD.addTextChangedListener(textWatcher);

        handler = new Handler()
        {
            @Override
            public void handleMessage(Message msg)
            {
                if(msg.what == 1)
                {
                    //Toast.makeText(LoginActivity.this,"登录成功",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent();
                    intent.setClass(LoginActivity.this, ClientActivity.class);
                    startActivity(intent);
                    finish();
                }
                if(msg.what == 2)
                {
                    Toast.makeText(LoginActivity.this,"账号或密码错误",Toast.LENGTH_SHORT).show();
                }
            }

        };

    }
}