package com.example.myclient;

import android.os.Message;
import android.util.Log;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

public class SendFile extends Thread{
    static Socket socket;
    OutputStream os;
    String Path;
    String FileName;
    float Percent = 0;
    TextView Stat;

    public SendFile(String Path, String FileName, TextView Stat)
    {
        this.Path = Path;
        this.FileName = FileName;
        this.Stat = Stat;
    }

    @Override
    public  void run(){
        try {

            os = socket.getOutputStream();
            os.write("SendFile".getBytes());
            sleep(240);
            os.write(FileName.getBytes());
            sleep(240);

            File file = new File(Path);
            FileInputStream inputStream = new FileInputStream(file);

            float FileSize = (file.length()/4096);
            byte[] buf = new byte[4096];
            int len;
            //判断是否读到文件末尾
            while ((len = inputStream.read(buf)) != -1) {
                os.write(buf, 0, len);//将文件循环写入输出流
                Percent++;

                if(Percent%32 == 0) {
                    Message msg = new Message();
                    msg.what = (int) ((Percent/FileSize)*100);
                    ClientActivity.handler.sendMessage(msg);
                    sleep(24);
                }
            }
            Stat.setText("发送完成");
            sleep(600);
            os.write("end".getBytes());
            Stat.setText("");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
